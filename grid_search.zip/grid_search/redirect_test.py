import datetime
import os

path_to_HPCG_exe =  "~/HPCG/hpcg/build/bin/xhpcg"
date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") # type: ignore

os.system(f"mpiexec.hydra -np 24 {path_to_HPCG_exe} > ../logs/{date}.out 2> ../logs/{date}.err")
